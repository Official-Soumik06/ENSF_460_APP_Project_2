/* 
 * File: HelperFunction.c  
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 24th, 2024
*/

#include <xc.h>
#include <math.h>
#include "string.h"
#include "UART2.h"
#include <p24F16KA101.h>
#include "clkChange.h"
#include "UART2.h"
#include "IOs.h"
#include "TimerDelay.h"
#include "ADC.h"
#include <stdio.h>
#include "HelperFunction.h"
#include "Global_Variables.h"

float ADC_To_Percentage(uint16_t Digital_Output) { // Converts The Digital Output Or ADC_Value that is read into a percentage
    float ADC_Percent = (float)Digital_Output / 1023.0f;  
    ADC_Percent = floorf(ADC_Percent * 100 + 0.5f) / 100.0f; // Round to two decimal places
    return ADC_Percent; // Returns The ADC_Value that is read as a percentage for PWM and Duty Cycle calculations to do with Potentiometer
}