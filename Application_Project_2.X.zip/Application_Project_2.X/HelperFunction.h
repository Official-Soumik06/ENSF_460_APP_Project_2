/* 
 * File: HelperFunction.h
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 24th, 2024
*/

#ifndef HELPERFUNCTION_H
#define	HELPERFUNCTION_H

#include <xc.h> // include processor files - each processor file is guarded.  

float ADC_To_Percentage(uint16_t Digital_Output); // Function Prototype To Convert The Read ADC_Output Value As A Percentage Value

#endif	/* XC_HEADER_TEMPLATE_H */

