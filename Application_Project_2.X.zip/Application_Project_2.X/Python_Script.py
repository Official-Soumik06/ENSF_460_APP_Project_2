"""
 * File:   Python_Script.py
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Completed: November 24th, 2024 
 * Editor: VScode
"""

import time
import serial
import pandas as pd
import plotly.express as px

# Adjusting the Plotly renderer for better compatibility with IDEs
import plotly.io as pio
pio.renderers.default = 'browser'

# Serial port settings
PORT = "COM5"
BAUD_RATE = 9600

# Initialize the serial connection
print("Opening Serial Port...")
ser = serial.Serial(port=PORT, baudrate=BAUD_RATE, bytesize=8, timeout=2, stopbits=serial.STOPBITS_ONE)

# Variables for storing data
data_str = ''            # String to hold the received data
data_list = []           # List for storing the data as integers
time_list = []           # List for storing the corresponding timestamps
start_time = time.time() # Time when data collection starts

# Start reading data from the serial port
print('Reading data for 60 seconds...')
while time.time() - start_time < 60:
    line = ser.readline()  # Read a line of data from the serial port
    if line not in [b' \n', b'\n']:  # Ignore empty lines
        data_str += line.decode('Ascii')  # Decode data into string
        time_list.append(time.time() - start_time)  # Record the timestamp

# Close the serial port once data collection is done
ser.close()
print("Data reading complete. Serial port closed.")

# Clean up and process the received data
data_str = data_str.replace('\x00', '').strip()  # Remove null bytes and strip extra spaces
raw_data = data_str.split(' \n ')  # Split the string by newline characters

# Convert the data to float and store in the list
for i, item in enumerate(raw_data):
    try:
        data_list.append(float(item))  # Convert each item to float
    except ValueError:
        print(f"Skipping invalid data at index {i}: {item}")  # Handle non-numeric values

# Make sure both lists are of the same length
min_length = min(len(time_list), len(data_list))
time_list = time_list[:min_length]
data_list = data_list[:min_length]

# Create a DataFrame for further analysis and visualization
df = pd.DataFrame({
    'Rx Time (sec)': time_list[4:],  # Time stamps for data
    'Rx Data ADC': data_list[4:],    # ADC data values
})

# Calculate intensity as a percentage
df['Intensity (%)'] = round((df['Rx Data ADC'] / 1024) * 100, 2)

# Generate file name dynamically based on the group number and name
group_name = "Group 22 - Soummadip, Hongwoo, Hyunmyung"
file_name = f"{group_name}_Data.csv"

# Save the DataFrame to CSV
df.to_csv(file_name, index=True)

# Plot the data using Plotly
print('Plotting Intensity vs Time...')
fig1 = px.line(df, x='Rx Time (sec)', y='Intensity (%)', title='Intensity (%) vs Time')
fig1.show()

print('Plotting ADC Data vs Time...')
fig2 = px.line(df, x='Rx Time (sec)', y='Rx Data ADC', title='ADC Value vs Time')
fig2.show()

# Final print statement
print('Data collection and plotting complete.')
