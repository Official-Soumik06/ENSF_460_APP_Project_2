/* 
 * File: IOs.h
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 24th, 2024
*/
#ifndef IOS_H
#define IOS_H

#include <xc.h>
// Function prototypes
void IOinit(void); // Function Prototype That Initializes And Configures The Peripherals
void IOcheck(PB1_Clicked, PB2_Clicked, PB3_Clicked); // Function Prototype For IOcheck() Which Updates The State Given A CN-Interrupt Triggering Causing The Push_Button_Flag To Be '1' 
#endif // IOS_H
