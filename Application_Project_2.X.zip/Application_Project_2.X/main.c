/* 
 * File: main.c
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 24th, 2024
*/


// FBS
#pragma config BWRP = OFF               // Table Write Protect Boot (Boot segment may be written)
#pragma config BSS = OFF                // Boot segment Protect (No boot program Flash segment)

// FGS
#pragma config GWRP = OFF               // General Segment Code Flash Write Protection bit (General segment may be written)
#pragma config GCP = OFF                // General Segment Code Flash Code Protection bit (No protection)

// FOSCSEL
#pragma config FNOSC = FRC              // Oscillator Select (Fast RC oscillator (FRC))
#pragma config IESO = OFF               // Internal External Switch Over bit (Two-Speed Start-up disabled)

// FOSC
#pragma config POSCMOD = NONE           // Primary Oscillator Configuration bits (Primary oscillator disabled)
#pragma config OSCIOFNC = ON            // CLKO Enable Configuration bit (CLKO output disabled; pin functions as port I/O)
#pragma config POSCFREQ = HS            // Primary Oscillator Frequency Range Configuration bits (>8 MHz)
#pragma config SOSCSEL = SOSCHP         // SOSC Power Selection Configuration bits (High-power operation)
#pragma config FCKSM = CSECMD           // Clock Switching and Monitor Selection (Clock switching enabled, Fail-Safe disabled)

// FWDT
#pragma config WDTPS = PS32768          // Watchdog Timer Postscale Select bits (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (1:128)
#pragma config WINDIS = OFF             // Windowed Watchdog Timer Disable bit (Standard WDT)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable bit (WDT disabled)

// FPOR
#pragma config BOREN = BOR3             // Brown-out Reset Enable bits (Enabled in hardware; SBOREN disabled)
#pragma config PWRTEN = ON              // Power-up Timer Enable bit (PWRT enabled)
#pragma config I2C1SEL = PRI            // Alternate I2C1 Pin Mapping bit (Default location)
#pragma config BORV = V18               // Brown-out Reset Voltage bits (1.8V)
#pragma config MCLRE = ON               // MCLR Pin Enable bit (MCLR pin enabled)

// FICD
#pragma config ICS = PGx2               // ICD Pin Placement Select bits (PGC2/PGD2)

// FDS
#pragma config DSWDTPS = DSWDTPSF       // Deep Sleep Watchdog Timer Postscale Select bits (25.7 Days)
#pragma config DSWDTOSC = LPRC          // DSWDT Reference Clock Select bit (LPRC)
#pragma config RTCOSC = SOSC            // RTCC Reference Clock Select bit (SOSC)
#pragma config DSBOREN = ON             // Deep Sleep Zero-Power BOR Enable bit (Enabled)
#pragma config DSWDTEN = ON             // Deep Sleep Watchdog Timer Enable bit (Enabled)

#include <xc.h>
#include <math.h>
#include "string.h"
#include "UART2.h"
#include <p24F16KA101.h>
#include "clkChange.h"
#include "UART2.h"
#include "IOs.h"
#include "TimerDelay.h"
#include "ADC.h"
#include <stdio.h>
#include "HelperFunction.h"
#include "Global_Variables.h"

// Push Button Status MACROS And LED Output Voltage MACRO:
#define PB1 PORTAbits.RA2
#define PB2 PORTBbits.RB4
#define PB3 PORTAbits.RA4
#define LED LATBbits.LATB8

// Initial State Of Each Trigger And Event: 
uint16_t Push_Button_Event = INITIAL_VALUE;
uint16_t Difference_In_ADC = INITIAL_VALUE;
uint16_t Past_ADC_Value = INITIAL_VALUE;
uint16_t Updated_ADC_Value = INITIAL_VALUE;
uint16_t Past_Percentage = INITIAL_VALUE;
uint16_t Updated_Percentage = INITIAL_VALUE;
uint16_t Percentage_Difference = INITIAL_VALUE;

// Initial Button Readings 
uint16_t PB1_Push_Reading = BUTTON_NOT_PRESSED;
uint16_t PB1_Lift_Reading = BUTTON_NOT_PRESSED;
uint16_t PB1_Clicked = BUTTON_NOT_CLICKED;
uint16_t PB2_Push_Reading = BUTTON_NOT_PRESSED;
uint16_t PB2_Lift_Reading = BUTTON_NOT_PRESSED;
uint16_t PB2_Clicked = BUTTON_NOT_CLICKED;
uint16_t PB3_Push_Reading = BUTTON_NOT_PRESSED;
uint16_t PB3_Lift_Reading = BUTTON_NOT_PRESSED;
uint16_t PB3_Clicked = BUTTON_NOT_CLICKED;

volatile uint16_t Power_State = OFF; // Initially Set OFF
volatile uint16_t LED_Mode = OFF; // Initially Set OFF
volatile uint16_t Sending_Data_Mode = SENDING_DATA_OFF; // Initially Do Not Send Data To Python Script, so OFF
volatile uint16_t LED_Blinking_Mode = BLINKING_OFF; // Initially Do Not Start The Blinking, so OFF

int main(void) {
    // Set all I/O pins as digital except for AN5 (which is analog input)
    AD1PCFG = 0xFFDF;

    // Initialize system clock with a frequency of 8 MHz
    newClk(8);

    // Initialize Input/Output (I/O) and other peripherals
    IOinit();

    // Initialize Timer 1, 2, and 3 for time-related events
    Timer_1_Initialization();
    Timer_2_Initialization();
    Timer_3_Initialization();

    // Initialize ADC (Analog to Digital Converter)
    ADC_Init();
    
    // Start ADC by setting the ADON bit (ADC is powered on)
    AD1CON1bits.ADON = 1;
    // Start sampling phase of ADC
    AD1CON1bits.SAMP = 1;
    // End sampling phase of ADC and start conversion
    AD1CON1bits.SAMP = 0;

    while (1) {
        // Check if the power is ON
        if (Power_State == ON) {
            // Check if a push button event occurred
            if (Push_Button_Event) {
                // Call IOcheck function to update state based on button clicks
                IOcheck(PB1_Clicked, PB2_Clicked, PB3_Clicked);
                Push_Button_Event = 0; // Reset button event flag
            }

            // Update ADC values
            Past_ADC_Value = Updated_ADC_Value;
            Updated_ADC_Value = do_ADC(); // Perform ADC conversion and update value
            
            // Check if the ADC value has changed
            if (Past_ADC_Value != Updated_ADC_Value) {
                Difference_In_ADC = 1; // Set flag indicating a change in ADC value
            } else {
                Difference_In_ADC = 0; // No change in ADC value
            }

            // If there is a change in ADC value, update percentage and handle LED behavior
            if (Difference_In_ADC) {
                // Convert ADC value to a percentage
                float ADC_Output_Percentage = ADC_To_Percentage(Updated_ADC_Value);
                
                // Save previous percentage and update the current percentage
                Past_Percentage = Updated_Percentage;
                Updated_Percentage = (uint16_t)(ADC_Output_Percentage * 100);
                
                // Calculate the difference in percentages
                if (Updated_Percentage > Past_Percentage) {
                    Percentage_Difference = Updated_Percentage - Past_Percentage;
                } else {
                    Percentage_Difference = Past_Percentage - Updated_Percentage;
                }

                // If the difference in percentage is greater than or equal to 2%
                if (Percentage_Difference >= 2) { // Threshold Check For Small Adjustments Of 2% To Adjust To
                    // If LED blinking mode is on, turn off Timer 3 (for blinking)
                    if (LED_Blinking_Mode == BLINKING_ON) {
                        T3CONbits.TON = 0;
                    }

                    // Disable timers and reset values for smooth operation
                    T1CONbits.TON = 0;
                    T2CONbits.TON = 0;
                    TMR1 = 0;
                    TMR2 = 0;

                    // Set new timer period values based on the updated percentage
                    PR1 = Updated_Percentage + 1;  // Set Timer 1 period
                    PR2 = 100 - Updated_Percentage + 1;  // Set Timer 2 period
                    LED = 1; // Turn on LED
                    T1CONbits.TON = 1; // Start Timer 1

                    // If LED blinking mode is on, enable Timer 3 for blinking effect
                    if (LED_Blinking_Mode == BLINKING_ON) {
                        T3CONbits.TON = 1;
                    }
                }
                // Reset the flag indicating a change in ADC value
                Difference_In_ADC = 0;
            }

            // If the data sending mode is on, display ADC value
            if (Sending_Data_Mode == SENDING_DATA_ON) {
                if (LED_Mode == ON) {
                    // Display updated ADC value as a decimal number on the display
                    Disp2Dec(Updated_ADC_Value);
                    Disp2String("\n"); // Print newline for formatting
                } else {
                    // If LED mode is off, display 0
                    Disp2Dec(0);
                    Disp2String("\n");
                }
            }

        } else { // If Power_State is OFF (0)
            // Enter idle mode when power is off
            Idle();
            // Check for button press event to update state
            if (Push_Button_Event) {
                IOcheck(PB1_Clicked, PB2_Clicked, PB3_Clicked); // Update state based on button clicks
                Push_Button_Event = 0; // Reset button event flag
            }
        }
    }
    return 0;
}

// Change Notification interrupt service routine
void __attribute__((interrupt, no_auto_psv)) _CNInterrupt(void) {
    // Update previous and current states for each button (PB1, PB2, PB3)
    PB1_Push_Reading = PB1_Lift_Reading;      // Save the last state of PB1 (button press)
    PB1_Lift_Reading = PB1;                   // Update current state of PB1
    
    PB2_Push_Reading = PB2_Lift_Reading;      // Save the last state of PB2
    PB2_Lift_Reading = PB2;                   // Update current state of PB2
    
    PB3_Push_Reading = PB2_Lift_Reading;      // Save the last state of PB3
    PB3_Lift_Reading = PB3;                   // Update current state of PB3

    // Check if a button click event occurred
    PB1_Clicked = (PB1_Push_Reading == BUTTON_NOT_PRESSED && PB1_Lift_Reading == BUTTON_PRESSED) 
                  ? BUTTON_CLICKED : BUTTON_NOT_CLICKED;   // PB1 was clicked
    
    PB2_Clicked = (PB2_Push_Reading == BUTTON_NOT_PRESSED && PB2_Lift_Reading == BUTTON_PRESSED) 
                  ? BUTTON_CLICKED : BUTTON_NOT_CLICKED;   // PB2 was clicked
    
    PB3_Clicked = (PB3_Push_Reading == BUTTON_NOT_PRESSED && PB3_Lift_Reading == BUTTON_PRESSED) 
                  ? BUTTON_CLICKED : BUTTON_NOT_CLICKED;   // PB3 was clicked

    // Set the event flag to indicate a button event occurred
    Push_Button_Event = 1;

    // Clear the Change Notification interrupt flag to acknowledge the interrupt
    IFS1bits.CNIF = 0;  // Clear CN interrupt flag
}

// Timer 3 interrupt service routine
void __attribute__((interrupt, no_auto_psv)) _T3Interrupt(void) {
    // Reset Timer 3 counter to zero
    TMR3 = 0;
    
    // Toggle the LED state based on its current state
    if (LED) {
        LED = 0;          // Turn off the LED
        LED_Mode = OFF;   // Update LED mode to OFF
        // Stop ongoing LED blinking by disabling Timer 1 and Timer 2
        T1CONbits.TON = 0; 
        T2CONbits.TON = 0;
        TMR1 = 0;
        TMR2 = 0;
    } else {
        LED = 1;          // Turn on the LED
        LED_Mode = ON;    // Update LED mode to ON
        // Start Timer 1 to control LED brightness
        T1CONbits.TON = 1;
    }
    
    // Clear the Timer 3 interrupt flag to acknowledge the interrupt
    IFS0bits.T3IF = 0;
    
    // Restart Timer 3 to generate the next interrupt
    T3CONbits.TON = 1;
}

// Timer 2 interrupt service routine
void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void) {
    // Stop Timer 2 and reset its counter
    T2CONbits.TON = 0;
    TMR2 = 0;
    
    // Toggle the LED state (ON/OFF)
    LED = !LED; 

    // Clear the Timer 2 interrupt flag to acknowledge the interrupt
    IFS0bits.T2IF = 0;
    
    // Start Timer 1 to manage LED brightness
    T1CONbits.TON = 1;
}

// Timer 1 interrupt service routine
void __attribute__((interrupt, no_auto_psv)) _T1Interrupt(void) {
    // Stop Timer 1 and reset its counter
    T1CONbits.TON = 0;
    TMR1 = 0;
    
    // Toggle the LED state (ON/OFF)
    LED = !LED; 

    // Clear the Timer 1 interrupt flag to acknowledge the interrupt
    IFS0bits.T1IF = 0;
    
    // Start Timer 2 for LED timing
    T2CONbits.TON = 1;
}
