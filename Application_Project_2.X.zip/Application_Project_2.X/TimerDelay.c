/* 
 * File: TimerDelay.c
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 24th, 2024
*/

#include <xc.h>
#include <p24F16KA101.h>
#include "clkChange.h"
#include "UART2.h"
#include "IOs.h"
#include "TimerDelay.h"
#include "ADC.h"
#include <stdio.h>
#include "HelperFunction.h"
#include "Global_Variables.h"

// Function to initialize Timer 1 with given parameters
void Timer_1_Initialization(){
    T1CONbits.TON = 0;                // Disable Timer 1 (ensure it's off before configuration)
    T1CONbits.TSIDL = 0;              // Continue operation in Idle mode (don't stop in Idle mode)
    T1CONbits.TCKPS = 0b10;           // Set Timer 1 prescaler to 64 (used to divide the clock frequency)
    T1CONbits.TCS = 0;                // Select internal instruction cycle clock (not external clock source)
    PR1 = 99;                         // Set the period for Timer 1 (determines the overflow period)
    TMR1 = 0;                         // Clear the Timer 1 register to start from 0
    IPC0bits.T1IP = 5;                // Set the interrupt priority for Timer 1 (priority 5)
    IFS0bits.T1IF = 0;                // Clear the Timer 1 interrupt flag (in case it was set)
    IEC0bits.T1IE = 1;                // Enable Timer 1 interrupt (allow the interrupt to be triggered)
}

// Function to initialize Timer 2 with given parameters
void Timer_2_Initialization(){
    T2CONbits.TON = 0;                // Disable Timer 2 before configuring
    T2CONbits.TSIDL = 0;              // Continue operation in Idle mode (don't stop in Idle mode)
    T2CONbits.T32 = 0;                // Ensure Timer 2 operates in 16-bit mode (not 32-bit mode)
    T2CONbits.TCKPS = 0b10;           // Set Timer 2 prescaler to 64 (divides the clock by 64)
    T2CONbits.TCS = 0;                // Select internal instruction cycle clock (not external clock source)
    PR2 = 2;                          // Set the period for Timer 2 (determines the overflow period)
    TMR2 = 0;                         // Clear the Timer 2 register to start from 0
    IPC1bits.T2IP = 2;                // Set the interrupt priority for Timer 2 (priority 2)
    IFS0bits.T2IF = 0;                // Clear the Timer 2 interrupt flag (in case it was set)
    IEC0bits.T2IE = 1;                // Enable Timer 2 interrupt (allow the interrupt to be triggered)
}

// Function to initialize Timer 3 with given parameters
void Timer_3_Initialization(){
    // Reset specific bits of Timer 3 Control Register to ensure a clean configuration
    T3CONbits.TON = 0;                // Disable Timer 3 (ensure it's off before configuration)
    T3CONbits.TSIDL = 0;              // Continue operation in Idle mode (don't stop in Idle mode)
    T3CONbits.TCKPS = 0b10;           // Set Timer 3 prescaler to 64 (divides the clock by 64)
    T3CONbits.TCS = 0;                // Select internal instruction cycle clock (not external clock source)
    
    // Ensure Timer 2 and Timer 3 operate independently (16-bit mode, not 32-bit)
    T2CONbits.T32 = 0;                // Ensure Timer 2 and Timer 3 operate in 16-bit mode
    
    PR3 = 31250;                      // Set the period for Timer 3 (determines the overflow period)
    TMR3 = 0;                         // Clear the Timer 3 register to start from 0
    IPC2bits.T3IP = 3;                // Set the interrupt priority for Timer 3 (priority 3)
    IFS0bits.T3IF = 0;                // Clear the Timer 3 interrupt flag (in case it was set)
    IEC0bits.T3IE = 1;                // Enable Timer 3 interrupt (allow the interrupt to be triggered)
}
