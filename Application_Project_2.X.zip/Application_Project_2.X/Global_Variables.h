/* 
 * File: Global_Variables.h
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 24th, 2024
*/

#ifndef GLOBAL_VARIABLES_H
#define GLOBAL_VARIABLES_H

#include <xc.h> // include processor files - each processor file is guarded.

extern volatile uint16_t Power_State;        // ON_MODE / OFF_MODE
extern volatile uint16_t LED_Mode;   // LED on/off
extern volatile uint16_t Sending_Data_Mode; // Sending data state
extern volatile uint16_t LED_Blinking_Mode; // Blinking state

#define RESET 0
#define INITIAL_VALUE 0
#define ON 1
#define OFF 0
#define SENDING_DATA_ON 1
#define SENDING_DATA_OFF 0
#define BLINKING_ON 1
#define BLINKING_OFF 0
#define BUTTON_CLICKED 1
#define BUTTON_NOT_CLICKED 0
#define BUTTON_PRESSED 0
#define BUTTON_NOT_PRESSED 1

extern  uint16_t Button_Press_Event;
extern  uint16_t Push_Button_Event;
extern  uint16_t Difference_In_ADC;
extern  uint16_t Past_ADC_Value;
extern  uint16_t Updated_ADC_Value;
extern  uint16_t Past_Percentage;
extern  uint16_t Updated_Percentage;
extern  uint16_t Percentage_Difference;
extern  uint16_t PB1_Push_Reading;
extern  uint16_t PB1_Lift_Reading;
extern  uint16_t PB1_Clicked;
extern  uint16_t PB2_Push_Reading;
extern  uint16_t PB2_Lift_Reading;
extern  uint16_t PB2_Clicked;
extern  uint16_t PB3_Push_Reading;
extern  uint16_t PB3_Lift_Reading;
extern  uint16_t PB3_Clicked;

#endif /* GLOBAL_VARIABLES_H */
