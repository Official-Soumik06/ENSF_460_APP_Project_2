/* 
 * File: TimerDelay.h  
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 24th, 2024
*/

#ifndef TIMERDELAY_H
#define TIMERDELAY_H

#include <xc.h>
// Function Declaration And Function Prototypes To Link Within The Header File
void Timer_1_Initialization(); // Timer 1 Initialization Function Prototype For Configuration And Initialization
void Timer_2_Initialization(); // Timer 2 Initialization Function Prototype For Configuration And Initialization
void Timer_3_Initialization(); // Timer 3 Initialization Function Prototype For Configuration And Initialization
#endif 