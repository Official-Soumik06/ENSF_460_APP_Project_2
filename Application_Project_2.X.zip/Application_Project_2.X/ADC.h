/* 
 * File: ADC.h 
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 24th, 2024
*/

#ifndef ADC_
#define ADC_

#include <xc.h>
void ADC_Init(); // Function Prototype To Configure And Initialize The 10-Bit ADC Module
uint16_t do_ADC(); // Function To Sample, Hold And Convert Analog Input Voltages Into Digital Output Value
#endif 