/* 
 * File: IOs.c
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 24th, 2024
*/

#include <xc.h>
#include <stdio.h>
#include <p24F16KA101.h>
#include "clkChange.h"
#include "UART2.h"
#include "IOs.h"
#include "TimerDelay.h"
#include "ADC.h"
#include "HelperFunction.h"
#include "Global_Variables.h"

#define PB1 PORTAbits.RA2
#define PB2 PORTBbits.RB4
#define PB3 PORTAbits.RA4
#define LED LATBbits.LATB8

void IOinit(){
    
    // INITIALIZING AND CONFIGURING THE PUSH BUTTONS 1,2,3 PERIPHERALS:
  
    TRISAbits.TRISA2 = 1; // Initialize The Direction As Input GPIO For PORT A RA2 Push Button 1 Connected To GPIO Pin 7
    CNPU2bits.CN30PUE = 1; // Pull Up Enable To Ensure Internal Voltage Signal For MCU Is "1" To Allow Toggling For The Push Button
    CNEN2bits.CN30IE = 1; // Change Notification Enable On Port A RA2 Push Button 1 On GPIO Pin 7
    
    TRISBbits.TRISB4 = 1; // Initialize The Direction As Input GPIO For PORT B RB4 Push Button 2 Connected To GPIO Pin 9      
    CNPU1bits.CN1PUE = 1; // Pull Up Enable To Ensure Internal Voltage Signal For MCU Is "1" To Allow Toggling For The Push Button      
    CNEN1bits.CN1IE = 1; // Change Notification Enable On Port B RB4 Push Button 2 On GPIO Pin 9
    
    TRISAbits.TRISA4 = 1; // Initialize The Direction As Input GPIO For PORT A RA4 Push Button 3 Connected To GPIO Pin 10          
    CNPU1bits.CN0PUE = 1; // Pull Up Enable To Ensure Internal Voltage Signal For MCU Is "1" To Allow Toggling For The Push Button           
    CNEN1bits.CN0IE = 1; // Change Notification Enable On Port A RA4 Push Button 3 On GPIO Pin 10
    
    // INITIALIZING AND CONFIGURING THE LED PERIPHERAL:
    
    TRISBbits.TRISB8 = 0; // Initialize The Direction As Output GPIO For PORT B RB8 LED Connected To GPIO Pin 12          
    
    // INITIALIZING AND CONFIGURING THE POTENTIOMETER PERIPHERAL:
    
    TRISAbits.TRISA3 = 1; // Initialize The Direction As Input GPIO For PORT A RA3 Potentiometer Connected To GPIO Pin 8
    AD1PCFGbits.PCFG5 = 0b0;; // Sets The AN5 To Analog Mode (Setting The AN5 Corresponding To The Potentiometer To Be Set As An Analog Input)
     
    // INITIALIZING AND CONFIGURING THE CHANGE NOTIFICATION INTERRUPT PERIPHERAL: 
      
    IPC4bits.CNIP = 6; // Setting The Priority Of The Change Notification Interrupt To "7"
    IFS1bits.CNIF = 0; // Setting The Flag Of The Change Notification Interrupt To "0"
    IEC1bits.CNIE = 1; // Enabling The Change Notification Interrupt
}

void IOcheck(PB1_Clicked, PB2_Clicked, PB3_Clicked) {
    // Check if PB1 was clicked (used to toggle the power state)
    if (PB1_Clicked == 1) {
        Power_State = !Power_State; // Toggle the power state (0 -> 1 or 1 -> 0)

        // Disable timers (turn off any active timer-related actions)
        T1CONbits.TON = 0;
        T2CONbits.TON = 0;
        T3CONbits.TON = 0;
        TMR1 = TMR2 = TMR3 = 0; // Reset the timer values to 0

        // If Power_State is OFF (0)
        if (Power_State == 0) {
            LED = 0; // Turn off LED
            LED_Mode = 0; // Set LED mode to OFF
        } else { // If Power_State is ON (1)
            LED = 1; // Turn on LED
            LED_Mode = 1; // Set LED mode to ON
            T1CONbits.TON = 1; // Turn on Timer 1
        }
    }

    // Switch-case based on the Power_State (either OFF_MODE or ON_MODE)
    switch (Power_State) {
        case 0: // Power is OFF, mode 0 (OFF_MODE)
            // Check if PB2 was clicked
            if (PB2_Clicked == 1) {
                Disp2Dec(LED_Blinking_Mode); // Display the current LED blinking mode (0 or 1)

                // If LED blinking is already enabled (1), turn it off
                if (LED_Blinking_Mode == 1) {
                    // Disable all timers
                    T1CONbits.TON = T2CONbits.TON = T3CONbits.TON = 0;
                    TMR1 = TMR2 = TMR3 = 0; // Reset timers
                    LED = 0; // Turn off LED
                    LED_Mode = 0; // Set LED mode to OFF
                    LED_Blinking_Mode = 0; // Disable LED blinking mode
                } else { // If LED blinking is off (0), enable it
                    // Disable all timers and reset their values
                    T1CONbits.TON = T2CONbits.TON = T3CONbits.TON = 0;
                    TMR1 = TMR2 = TMR3 = 0;
                    PR1 = 100; // Set period for Timer 1
                    PR2 = 1;   // Set period for Timer 2
                    LED_Blinking_Mode = 1; // Enable LED blinking mode
                    LED = 1;   // Turn on LED
                    LED_Mode = 1; // Set LED mode to ON
                    T3CONbits.TON = 1; // Enable Timer 3 (for blinking)
                }
            }
            break;

        case 1: // Power is ON, mode 1 (ON_MODE)
            // Check if PB2 was clicked
            if (PB2_Clicked) {
                T3CONbits.TON ^= 1; // Toggle the blinking state (turn on/off Timer 3)
                T1CONbits.TON = 1;  // Ensure Timer 1 is always on
            }
            // Check if PB3 was clicked (used to toggle the sending data mode)
            if (PB3_Clicked) {
                Sending_Data_Mode = !Sending_Data_Mode; // Toggle the sending data mode
            }
            break;
    }
}


    





    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 