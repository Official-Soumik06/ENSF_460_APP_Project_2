/* 
 * File: ADC.c 
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 24th, 2024
*/


#include <xc.h>
#include <p24F16KA101.h>
#include "clkChange.h"
#include "UART2.h"
#include "IOs.h"
#include "TimerDelay.h"
#include "ADC.h"
#include <stdio.h>
#include "HelperFunction.h"
#include "Global_Variables.h"
#include <math.h>

void ADC_Init(void){
    
AD1CON1bits.FORM = 0b00; // Set the data output format (unsigned integer)
AD1CON1bits.SSRC = 0b111; // Select the conversion trigger source
AD1CON1bits.ASAM = 0;     // Disable auto-start for the A/D sample

AD1CON2bits.VCFG = 0b000; // Selects The Supply Voltage To The MCU As The Reference Voltage Or 'Vref'
AD1CON2bits.CSCNA = 0;    // Disable input scan for MUX A (Single Channel mode)
AD1CON2bits.SMPI = 0b000; // Set the number of conversions per interrupt (1 conversion)
AD1CON2bits.BUFM = 0;     // Select the buffer mode (single 16-bit buffer)
AD1CON2bits.ALTS = 0;     // Disable alternate input sample mode

AD1CON3bits.ADRC = 0; // ADC Is Set To Use The System Clock
AD1CON3bits.SAMC = 0b11111; // Set the auto-sample time to maximum

AD1CHSbits.CH0NB = 0;     // Select the negative input for MUX B (channel 0)
AD1CHSbits.CH0SB = 0b0101; // Select the positive input for MUX B (channel 0)

AD1CHSbits.CH0NA = 0;     // Select the negative input for MUX A (channel 0)
AD1CHSbits.CH0SA = 0b0101; // Select the positive input for MUX A (channel 0)
AD1CSSL = 0x0000;         // Disable scanning of any analog channels

return;
}

uint16_t do_ADC(void) {
        
    // CONFIGURING AND SETTING UP THE ADC MODULE:
    
    uint16_t ADC_Value; // 16-Bit Unsigned Integer Variable/Register That Stores The Converted ADC Digital Output From The Buffer Register
    
    AD1CON1bits.ADON = 1; // Setting The ADC Operating Mode To '1' Which Corresponds To Turning The ADC Module 'ON'
    
    // SETTING UP THE SAMPLING AND CONVERSION LOGIC FOR THE ADC:
    
    AD1CON1bits.SAMP = 1; // Starts The Sampling Of The Analog Input Voltages Then Starts Conversion Automatically Due To System Trigger
    
    while(AD1CON1bits.DONE == 0){} // While Loop Is Used To Wait For The Conversion Of The Sampled Analog Input Voltages To Be Converted Into A Digital Output, When The Conversion Finishes The 'DONE' Will Be Flagged And Set To '1' Indicating That The Conversion Completed Successfully
    
    ADC_Value = ADC1BUF0; // Store The Digital Output From Sample Analog Input Voltage Conversion Into A Digital Output Into The 'ADC_Value' Variable
    
    AD1CON1bits.ADON = 0; // Setting The ADC Operating Mode To '0' Which Corresponds To Turning The ADC Module 'OFF'

    return ADC_Value; // Return The 10-Bit ADC Digital Output To The Function That Called For An ADC Sample/Hold/Conversion Value From The Analog Input Voltages To A Digital Output
}

