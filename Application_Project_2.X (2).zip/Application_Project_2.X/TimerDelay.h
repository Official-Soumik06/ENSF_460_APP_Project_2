/* 
 * File: TimerDelay.h  
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 8th, 2024
*/

#ifndef TIMERDELAY_H
#define TIMERDELAY_H

#include <xc.h>
// Function Declaration And Function Prototypes To Link Within The Header File
void Debounce_Delay();
void T1init();
void T2init();
void T3init();
#endif 