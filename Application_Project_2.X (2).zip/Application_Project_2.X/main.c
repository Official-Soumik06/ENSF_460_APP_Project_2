/* 
 * File: main.c  
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 8th, 2024
*/

// FBS
#pragma config BWRP = OFF               // Table Write Protect Boot (Boot segment may be written)
#pragma config BSS = OFF                // Boot segment Protect (No boot program Flash segment)

// FGS
#pragma config GWRP = OFF               // General Segment Code Flash Write Protection bit (General segment may be written)
#pragma config GCP = OFF                // General Segment Code Flash Code Protection bit (No protection)

// FOSCSEL
#pragma config FNOSC = FRC              // Oscillator Select (Fast RC oscillator (FRC))
#pragma config IESO = OFF               // Internal External Switch Over bit (Internal External Switchover mode disabled (Two-Speed Start-up disabled))

// FOSC
#pragma config POSCMOD = NONE           // Primary Oscillator Configuration bits (Primary oscillator disabled)
#pragma config OSCIOFNC = ON            // CLKO Enable Configuration bit (CLKO output disabled; pin functions as port I/O)
#pragma config POSCFREQ = HS            // Primary Oscillator Frequency Range Configuration bits (Primary oscillator/external clock input frequency greater than 8 MHz)
#pragma config SOSCSEL = SOSCHP         // SOSC Power Selection Configuration bits (Secondary oscillator configured for high-power operation)
#pragma config FCKSM = CSECMD           // Clock Switching and Monitor Selection (Clock switching is enabled, Fail-Safe Clock Monitor is disabled)

// FWDT
#pragma config WDTPS = PS32768          // Watchdog Timer Postscale Select bits (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (WDT prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Windowed Watchdog Timer Disable bit (Standard WDT selected; windowed WDT disabled)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable bit (WDT disabled (control is placed on the SWDTEN bit))

// FPOR
#pragma config BOREN = BOR3             // Brown-out Reset Enable bits (Brown-out Reset enabled in hardware; SBOREN bit disabled)
#pragma config PWRTEN = ON              // Power-up Timer Enable bit (PWRT enabled)
#pragma config I2C1SEL = PRI            // Alternate I2C1 Pin Mapping bit (Default location for SCL1/SDA1 pins)
#pragma config BORV = V18               // Brown-out Reset Voltage bits (Brown-out Reset set to lowest voltage (1.8V))
#pragma config MCLRE = ON               // MCLR Pin Enable bit (MCLR pin enabled; RA5 input pin disabled)

// FICD
#pragma config ICS = PGx2               // ICD Pin Placement Select bits (PGC2/PGD2 are used for programming and debugging the device)

// FDS
#pragma config DSWDTPS = DSWDTPSF       // Deep Sleep Watchdog Timer Postscale Select bits (1:2,147,483,648 (25.7 Days))
#pragma config DSWDTOSC = LPRC          // DSWDT Reference Clock Select bit (DSWDT uses LPRC as reference clock)
#pragma config RTCOSC = SOSC            // RTCC Reference Clock Select bit (RTCC uses SOSC as reference clock)
#pragma config DSBOREN = ON             // Deep Sleep Zero-Power BOR Enable bit (Deep Sleep BOR enabled in Deep Sleep)
#pragma config DSWDTEN = ON             // Deep Sleep Watchdog Timer Enable bit (DSWDT enabled)

// #pragma config statements should precede project file includes.

#include <xc.h>
#include <p24F16KA101.h>
#include "clkChange.h"
#include "UART2.h"
#include "IOs.h"
#include "TimerDelay.h"
#include "ADC.h"
#include <stdio.h>
#include "HelperFunctions.h"

#define PB1 PORTAbits.RA2 // The MACRO 'PB1' Holds The Status Of The Push Button 1 On Pin 7 Of Port RA2 (Digital Input)
#define PB2 PORTBbits.RB4 // The MACRO 'PB2' Holds The Status Of The Push Button 2 On Pin 9 Port RB4 (Digital Input)
#define PB3 PORTAbits.RA4 // The MACRO 'PB3' Holds The Status Of The Push Button 3 On Pin 10 Port RA4 (Digital Input)
#define LED LATBbits.LATB8 // The MACRO 'LED' Holds The Status Of The LED Light Connected To Pin 12 Port RB8 (Digital Output)

#define OFF_STATE 0
#define OFF_SOLID_BLINKING_STATE 1
#define ON_SOLID_INTENSITY_STATE 2
#define ON_BLINKING_INTENSITY_STATE 3
#define DATA_TRANSMISSION_STATE 4
#define BUTTON_CLICKED 0
#define BUTTON_NOT_CLICKED 1

volatile uint16_t Wake_CPU;
volatile uint16_t Debounce_Complete;
volatile uint16_t PB1_Pressed;
volatile uint16_t PB2_Pressed;
volatile uint16_t PB3_Pressed;
volatile uint16_t Current_State;
volatile uint16_t PWM_Counter;
volatile uint16_t Duty_Cycle;
volatile uint16_t ADC_Output;

int main(void) {
    
    AD1PCFG = 0xFFDF; // This keeps all other pins and analog inputs configured as digital, except for GPIO Pin 8 (RA3), which is set as an analog input (AN5).
    
    newClk(8); // Use the initial clock frequency of 8 MHz
   
    IOinit(); // Initialize the digital input and output devices, like push buttons and the LED
       
    InitUART2(); // Initialize UART2 for serial communication
    
    ADC_Init(); // Initialize the ADC module for analog input reading
    
    T1init(); // Initialize Timer 1
    T2init(); // Initialize Timer 2
    T3init(); // Initialize Timer 3
    
    Current_State = OFF_STATE; // The initial state is set to 'OFF_STATE'
    
    while(1) {
  
        // Check if the CPU is allowed to wake up from idle
        if(Wake_CPU){
            
            // Perform I/O checking and processing
            IOcheck();
            
            // Switch based on the current state to determine LED behavior and other actions
            switch(Current_State) {
            
            case OFF_STATE: // LED OFF, CPU enters sleep mode
                Stop_Blinking();
                LED = 0;       // Turn off LED
                break;
                
            case OFF_SOLID_BLINKING_STATE: // LED blinking on/off at 0.5s intervals
                Start_Blinking(); // Blinks The LED ON and OFF For 0.5s Intervals
                break;
                
            case ON_SOLID_INTENSITY_STATE: // LED solid, changing intensity (dim/bright) with potentiometer
                Stop_Blinking();
                break;
                
            case ON_BLINKING_INTENSITY_STATE: // LED blinking with intensity change (dim/bright) with potentiometer
                
                break;
                
            case DATA_TRANSMISSION_STATE: // Data transmission to Python script (e.g., ADC values)
                // Implement data transmission logic here
                break;
            }
        }       
        Idle(); // After handling the state processes, return the CPU to idle mode until the next CN-Interrupt is triggered to ensure proper CPU rest and efficiency
    }
    return 0;
}


// TIMER 1 INTERRUPT SUB ROUTINE:

void __attribute__((interrupt,no_auto_psv)) _T1Interrupt(void){
    IFS0bits.T1IF = 0; // Clear Timer 1 Interrupt Flag
    T1CONbits.TON = 0; // Set The Timer 1 To OFF
    Debounce_Complete = 1; // Set Flag To 1 Indicating That The Debounce Delay Was Completed
}

// TIMER 2 INTERRUPT SUB ROUTINE:
void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void){
    LED = !LED; // Toggle The LED ON or OFF Every Timer 2 Interrupt Trigger Which Is Every 0.5s
    IFS0bits.T2IF = 0; // Clear The Timer 2 Interrupt Flag
}

// TIMER 3 INTERRUPT SUB ROUTINE:
void __attribute__((interrupt, no_auto_psv)) _T3Interrupt(void){
    IFS0bits.T3IF = 0; // Clear The Timer 3 Interrupt Flag
}

// CHANGE NOTIFICATION INTERRUPT SUB ROUTINE: 
void __attribute__((interrupt, no_auto_psv)) _CNInterrupt(void) {
 // Don't forget to clear the CN interrupt flag!
    IFS1bits.CNIF = 0;
    Wake_CPU = 1;
    // Clear All The Flags From The Start Of The CN-Interrupt To Avoid Any Voltage Signal State Confusion
    PB1_Pressed = 0;
    PB2_Pressed = 0;
    PB3_Pressed = 0;
    // Set The Button Flags Based On Pressed Condition
    PB1_Pressed = (PB1 == 0) ? BUTTON_CLICKED : BUTTON_NOT_CLICKED;
    PB2_Pressed = (PB2 == 0) ? BUTTON_CLICKED : BUTTON_NOT_CLICKED;
    PB3_Pressed = (PB3 == 0) ? BUTTON_CLICKED : BUTTON_NOT_CLICKED;
}
