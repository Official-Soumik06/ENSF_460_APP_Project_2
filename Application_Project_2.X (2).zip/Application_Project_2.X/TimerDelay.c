/* 
 * File: TimerDelay.c
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): October 10th, 2024
*/

#include <xc.h>
#include <p24F16KA101.h>
#include "clkChange.h"
#include "UART2.h"
#include "IOs.h"
#include "TimerDelay.h"
#include "ADC.h"
#include <stdio.h>
#include "HelperFunctions.h"

void Debounce_Delay() {
    // Starting The Debounce Delay Timer Which Corresponds To The Usage Of Timer 1:
    TMR1 = 0; // Reset/Clear The Timer 1 Register Value
    PR1 = 1250; // 1250 Cycles Is Equivalent To A 20ms Debounce Delay In A Clock Frequency Of 8MHz
    T1CONbits.TON = 1; // Turn The Timer On
}

void T1init() {
    // TIMER 1 INITIALIZATION AND CONFIGURATION:
    T1CONbits.TSIDL = 0;   // Operate in idle mode
    T1CONbits.TCKPS = 0b10; // Prescaler 1:64
    T1CONbits.TCS = 0;     // Use internal clock
    IPC0bits.T1IP = 5;     // Priority level
    IFS0bits.T1IF = 0;     // Clear Timer 1 interrupt flag
    IEC0bits.T1IE = 1;     // Enable Timer 1 interrupt
    T1CONbits.TON = 0;     // Timer initially off
}

void T2init() {
    // TIMER 2 INITIALIZATION AND CONFIGURATION:
    T2CONbits.TSIDL = 0;    // Ensure the timer operates in normal mode, not idle mode (timer continues running in CPU idle)
    T2CONbits.T32 = 0;      // Configure Timer 2 as a 16-bit timer (not a 32-bit timer)
    T2CONbits.TCKPS = 0b10; // Set the prescaler value to 1:64 (timer input clock frequency will be divided by 64)
    T2CONbits.TCS = 0;      // Use the internal clock (FOSC/2) as the timer source, not an external clock
    IPC1bits.T2IP = 2;      // Set the interrupt priority of Timer 2 to 2 (scale of 1-7, where 7 is the highest priority)
    IFS0bits.T2IF = 0;      // Clear the interrupt flag for Timer 2 to ensure no pending interrupts
    IEC0bits.T2IE = 1;      // Enable the interrupt for Timer 2 (allow the interrupt to trigger when the timer overflows)
    PR2 = 0;                // Set the period register (PR2) to 0 (timer will count to 0 and trigger an interrupt)
    TMR2 = 0;               // Initialize the timer register (TMR2) to 0 (reset the timer counter)
    T2CONbits.TON = 0;      // Set Timer 2 Turned OFF
}

void T3init() {
    T3CONbits.TSIDL = 0;       // Operate in idle mode (timer continues in sleep mode)
    T2CONbits.T32 = 0;         // Operate as a 16-bit timer
    T3CONbits.TCKPS = 0b10;    // Set prescaler to 1:64
    T3CONbits.TCS = 0;         // Use internal clock (not external clock source)
    IPC2bits.T3IP = 3;         // Set priority level of Timer 3 interrupt to 3
    IFS0bits.T3IF = 0;         // Clear Timer 3 interrupt flag
    IEC0bits.T3IE = 1;         // Enable Timer 3 interrupt
    PR3 = 31250;               // Set PR3 to 31250 for a 0.5-second period with 8 MHz clock & 1:64 prescaler
    TMR3 = 0;                  // Clear Timer 3 register to ensure it starts from 0
    T3CONbits.TON = 0;         // Ensure Timer 3 is initially off
}

