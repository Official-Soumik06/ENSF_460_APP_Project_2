/* 
 * File: IOs.c
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 8th, 2024
*/

#include <xc.h>
#include <p24F16KA101.h>
#include "clkChange.h"
#include "UART2.h"
#include "IOs.h"
#include "TimerDelay.h"
#include "ADC.h"
#include <stdio.h>

#define LED LATBbits.LATB8 // The MACRO 'LED' Holds The Status Of The LED Light Connected To Pin 12 Port RB8 (Digital Output)
#define OFF_STATE 0
#define OFF_SOLID_BLINKING_STATE 1
#define ON_SOLID_INTENSITY_STATE 2
#define ON_BLINKING_INTENSITY_STATE 3
#define DATA_TRANSMISSION_STATE 4
#define BUTTON_CLICKED 0
#define BUTTON_NOT_CLICKED 1

void Start_Blinking(){
    TMR2 = 0; // Reset/Clear The Timer 2 Register Value
    PR2 = 31250; // 31250 Cycles Is Equivalent To A 500ms or 0.5s Delay In A Clock Frequency Of 8MHz
    T2CONbits.TON = 1; // Turn The Timer 2 ON Which Starts The Blinking
}

void Stop_Blinking(){
    T2CONbits.TON = 0; // Turn The Timer 2 OFF Which Stops The Blinking 
    LED = 0; // Force-Fully Turn The LED OFF When The Timer Is Turned OFF
}
