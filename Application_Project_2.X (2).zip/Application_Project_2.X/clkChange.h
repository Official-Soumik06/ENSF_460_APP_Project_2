/* 
 * File: clkChange.h  
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 8th, 2024
*/

#ifndef CHANGECLK_H
#define CHANGECLK_H

#include <xc.h>

// Function Declaration And Function Prototype To Link Within The Header File
void newClk(unsigned int clkval);

#endif // CHANGECLK_H
