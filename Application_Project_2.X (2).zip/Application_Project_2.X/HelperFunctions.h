


#ifndef HELPERFUNCTIONS_H
#define	HELPERFUNCTIONS_H

#include <xc.h> // include processor files - each processor file is guarded.  

void Start_Blinking();
void Stop_Blinking();
#endif