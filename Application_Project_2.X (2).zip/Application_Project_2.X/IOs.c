/* 
 * File: IOs.c
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 8th, 2024
*/

#include <xc.h>
#include <stdio.h>
#include <p24F16KA101.h>
#include "clkChange.h"
#include "UART2.h"
#include "IOs.h"
#include "TimerDelay.h"
#include "ADC.h"
#include "HelperFunctions.h"

#define OFF_STATE 0
#define OFF_SOLID_BLINKING_STATE 1
#define ON_SOLID_INTENSITY_STATE 2
#define ON_BLINKING_INTENSITY_STATE 3
#define DATA_TRANSMISSION_STATE 4
#define BUTTON_CLICKED 0
#define BUTTON_NOT_CLICKED 1

void IOinit(){
    
    // INITIALIZING AND CONFIGURING THE PUSH BUTTONS 1,2,3 PERIPHERALS:
  
    TRISAbits.TRISA2 = 1; // Initialize The Direction As Input GPIO For PORT A RA2 Push Button 1 Connected To GPIO Pin 7
    CNPU2bits.CN30PUE = 1; // Pull Up Enable To Ensure Internal Voltage Signal For MCU Is "1" To Allow Toggling For The Push Button
    CNEN2bits.CN30IE = 1; // Change Notification Enable On Port A RA2 Push Button 1 On GPIO Pin 7
    
    TRISBbits.TRISB4 = 1; // Initialize The Direction As Input GPIO For PORT B RB4 Push Button 2 Connected To GPIO Pin 9      
    CNPU1bits.CN1PUE = 1; // Pull Up Enable To Ensure Internal Voltage Signal For MCU Is "1" To Allow Toggling For The Push Button      
    CNEN1bits.CN1IE = 1; // Change Notification Enable On Port B RB4 Push Button 2 On GPIO Pin 9
    
    TRISAbits.TRISA4 = 1; // Initialize The Direction As Input GPIO For PORT A RA4 Push Button 3 Connected To GPIO Pin 10          
    CNPU1bits.CN0PUE = 1; // Pull Up Enable To Ensure Internal Voltage Signal For MCU Is "1" To Allow Toggling For The Push Button           
    CNEN1bits.CN0IE = 1; // Change Notification Enable On Port A RA4 Push Button 3 On GPIO Pin 10
    
    // INITIALIZING AND CONFIGURING THE LED PERIPHERAL:
    
    TRISBbits.TRISB8 = 0; // Initialize The Direction As Output GPIO For PORT B RB8 LED Connected To GPIO Pin 12          
    
    // INITIALIZING AND CONFIGURING THE POTENTIOMETER PERIPHERAL:
    
    TRISAbits.TRISA3 = 1; // Initialize The Direction As Input GPIO For PORT A RA3 Potentiometer Connected To GPIO Pin 8
    AD1PCFGbits.PCFG5 = 0b0;; // Sets The AN5 To Analog Mode (Setting The AN5 Corresponding To The Potentiometer To Be Set As An Analog Input)
     
    // INITIALIZING AND CONFIGURING THE CHANGE NOTIFICATION INTERRUPT PERIPHERAL: 
      
    IPC4bits.CNIP = 6; // Setting The Priority Of The Change Notification Interrupt To "7"
    IFS1bits.CNIF = 0; // Setting The Flag Of The Change Notification Interrupt To "0"
    IEC1bits.CNIE = 1; // Enabling The Change Notification Interrupt
}


void IOcheck(){

Debounce_Delay(); // Debounce Delay Of 20ms To Ensure Only One Push Button Click Is Validated And Captured
    
if(Debounce_Complete){ // Enter This If-Statement If The Debounce Delay Has Completed
    if(PB1_Pressed){
        if(Current_State == OFF_STATE){
            Current_State = ON_SOLID_INTENSITY_STATE;
            Debounce_Complete = 0;
        }
        else if(Current_State == ON_SOLID_INTENSITY_STATE){
            Current_State = OFF_STATE;
            Debounce_Complete = 0;
        }
    }
    if(PB2_Pressed){
        if(Current_State == OFF_STATE){
            Current_State = OFF_SOLID_BLINKING_STATE;
            Debounce_Complete = 0;
        }
        else if(Current_State == ON_SOLID_INTENSITY_STATE){
            Current_State = ON_BLINKING_INTENSITY_STATE;
            Debounce_Complete = 0;
        }
        else if(Current_State == OFF_SOLID_BLINKING_STATE){
            Current_State = OFF_STATE;
            Debounce_Complete = 0;
        }
        else if(Current_State == ON_BLINKING_INTENSITY_STATE){
            Current_State = OFF_STATE; 
            Debounce_Complete = 0;
        }
    }   
    if(PB3_Pressed){
        
    }        
    }
}
    





    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 