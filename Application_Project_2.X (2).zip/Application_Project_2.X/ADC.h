/* 
 * File: ADC.h 
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 8th, 2024
*/

#ifndef ADC_H
#define ADC_H

#include <xc.h>
void ADC_Init(void);
uint16_t do_ADC(void); // The 'do_ADC(void)' Function Declaration And Prototype 
#endif // ADC_H