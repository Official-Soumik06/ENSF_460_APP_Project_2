/* 
 * File: IOs.h
 * Authors: Soummadip, Hongwoo, Hyunmyung
 * Date (Finished): November 8th, 2024
*/
#ifndef IOS_H
#define IOS_H

#include <xc.h>
// Global Variables In Scope Of Other Files In This Directory
extern volatile uint16_t Wake_CPU;
extern volatile uint16_t Debounce_Complete;
extern volatile uint16_t PB1_Pressed;
extern volatile uint16_t PB2_Pressed;
extern volatile uint16_t PB3_Pressed;
extern volatile uint16_t Current_State;
extern volatile uint16_t PWM_Counter;
extern volatile uint16_t Duty_Cycle;
extern volatile uint16_t ADC_Output;            
// Function Declaration And Function Prototypes To Link Within The Header File
void IOinit();
void IOcheck();
void Mode_Select(uint16_t mode_Type);
void Display_Progress_Bar(uint16_t Digital_ADC);
#endif 

